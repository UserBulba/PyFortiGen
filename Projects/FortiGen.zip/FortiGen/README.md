# FortiGen

FortiGen is a simple tool that helps you automate generating configuration files.

![FortiGen](Image/logo.png)